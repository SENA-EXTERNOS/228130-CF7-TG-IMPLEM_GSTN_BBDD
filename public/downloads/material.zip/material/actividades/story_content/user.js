function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6CW4hz4YqXr":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

